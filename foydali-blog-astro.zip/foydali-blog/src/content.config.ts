import { defineCollection, z } from "astro:content";

const articles = defineCollection({
  type: "content",
  schema: z.object({
    title: z.string(),
    description: z.string(),
    pubDate: z.coerce.date(),
    author: z.string().default("Foydali Blog jamoasi"),
    category: z.string(),
    image: z.string(),
    imageAlt: z.string(),
    featured: z.boolean().default(false),
  }),
});

export const collections = { articles };
