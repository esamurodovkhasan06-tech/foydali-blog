# Foydali Blog — Astro + TypeScript

O‘zbek tilidagi maqolalar blogi. Astro, TypeScript, Markdown va GitHub Pages uchun tayyorlangan.

## 1. Kerakli dasturlar

- Node.js LTS (tavsiya: Node.js 22)
- Git
- GitHub akkaunti
- VS Code (tavsiya etiladi)

Node.js o‘rnatilgach terminalda tekshiring:

```bash
node -v
npm -v
```

## 2. Loyihani ishga tushirish

ZIP arxivni oching va terminalda loyiha papkasiga kiring:

```bash
cd foydali-blog
npm install
npm run dev
```

Terminal ko‘rsatgan mahalliy manzilni brauzerda oching (odatda `http://localhost:4321`).

## 3. GitHub Pages manzilini sozlash

`astro.config.mjs` faylini oching. Quyidagi qiymatlarni o‘zgartiring:

```js
site: "https://YOUR-USERNAME.github.io",
base: "/foydali-blog",
```

Masalan, GitHub foydalanuvchingiz `ali123` bo‘lsa va repository nomi `foydali-blog` bo‘lsa:

```js
site: "https://ali123.github.io",
base: "/foydali-blog",
```

Repository nomini boshqa tanlasangiz, `base` qiymatini ham `"/repository-nomi"` qilib o‘zgartiring.
Agar `ali123.github.io` nomli maxsus user/organization repository ishlatsangiz, `base: "/"` bo‘lishi kerak.

## 4. GitHub orqali internetga chiqarish

1. GitHub’da `foydali-blog` nomli yangi repository yarating.
2. ZIP ichidagi fayllarni loyiha papkasiga oching.
3. Terminalda quyidagilarni bajaring:

```bash
git init
git add .
git commit -m "Foydali Blog saytini yaratish"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/foydali-blog.git
git push -u origin main
```

`YOUR-USERNAME` o‘rniga GitHub foydalanuvchi nomingizni yozing.

4. GitHub repository → **Settings → Pages** bo‘limiga kiring.
5. **Build and deployment → Source** qismida **GitHub Actions** tanlanganini tekshiring.
6. **Actions** bo‘limida `Deploy Astro site to GitHub Pages` jarayoni tugashini kuting.
7. Sayt manzili odatda `https://YOUR-USERNAME.github.io/foydali-blog/` bo‘ladi.

Har safar `main` branch’iga yangi kod yuborilsa, GitHub Actions saytni qayta build va deploy qiladi.

## 5. Yangi maqola qo‘shish

`src/content/articles/` papkasida yangi `.md` fayl yarating. Masalan, `kitobxonlik.md`:

```md
---
title: "Kitob o‘qishning foydali usullari"
description: "Kitob o‘qishni kundalik odatga aylantirish bo‘yicha tavsiyalar."
pubDate: 2026-10-19
author: "Muallif ismi"
category: "Ta’lim"
image: "https://example.com/rasm.jpg"
imageAlt: "Kitob o‘qiyotgan inson"
featured: false
---

Maqola matnini shu yerga yozing.

## Birinchi bo‘lim

Matnni davom ettiring.
```

`image` uchun mavjud va ommaviy rasm URL manzilidan foydalaning. Yaxshiroq nazorat uchun rasmlarni `public/images/` ichiga qo‘yib, masalan `/foydali-blog/images/kitob.jpg` shaklida ko‘rsatish mumkin. Agar shunday qilsangiz, repository nomiga mos yo‘lni kiriting.

## 6. Build tekshiruvi

```bash
npm run build
```

Bu buyruq `astro check` va `astro build` ishlarini bajaradi. Tayyor statik fayllar `dist/` papkasiga yoziladi. Lokal ko‘rish uchun:

```bash
npm run preview
```

Build xatosiz tugasa, terminalda yakuniy muvaffaqiyat xabari ko‘rinadi.

## Eslatmalar

- Aloqa sahifasidagi `foydaliblog@example.com` manzilini haqiqiy emailingiz bilan almashtiring.
- Maqolalar Markdown fayllarida saqlanadi; har bir maqola uchun alohida sahifa build vaqtida yaratiladi.
- Qidiruv va kategoriya filtri brauzerda ishlaydi, server talab qilmaydi.
- Sitemap `@astrojs/sitemap` integratsiyasi orqali build vaqtida yaratiladi.
- Rasmlar demo uchun Unsplash manzillaridan olinadi; ularni o‘zingiz tanlagan, foydalanishga ruxsat berilgan rasmlarga almashtirishingiz mumkin.
