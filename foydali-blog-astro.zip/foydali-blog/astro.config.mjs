import { defineConfig } from "astro/config";
import sitemap from "@astrojs/sitemap";

// GitHub Pages uchun quyidagi ikkita qiymatni o'zingizga moslang.
// Masalan: GitHub foydalanuvchingiz ali123 bo'lsa, site: "https://ali123.github.io"
// Repository nomi foydali-blog bo'lsa, base: "/foydali-blog".
export default defineConfig({
  site: "https://YOUR-USERNAME.github.io",
  base: "/foydali-blog",
  integrations: [sitemap()],
});
